-- Databricks notebook source
--DROP TABLE silver_adv_details;
DROP TABLE gold_castaways;